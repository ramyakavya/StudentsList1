package edu.kennesaw.service;

/**
 * Created by snellipudi on 8/2/2017.
 */
public class UserService {
}
