package edu.kennesaw.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Created by snellipudi on 8/2/2017.
 */
@Controller
public class LoginController {

    @Autowired
    private LoginDelegate loginDelegate;

    @RequestMapping(value = "/login", method = RequestMethod.GET)
    public ModelAndView showLogin(HttpServletRequest request, HttpServletResponse response) {
        ModelAndView mav = new ModelAndView("login");
        mav.addObject("login", new Login());
        return mav;
    }


    @RequestMapping(value = "/login", method = RequestMethod.POST)
    public ModelAndView loginProcess(HttpServletRequest request, HttpServletResponse response,
                                     @ModelAttribute("loginBean") LoginBean loginBean) {
        ModelAndView mav = null;
        try{
            boolean isValidUser = loginDelegate.isValidUser(loginBean.getUsername(),loginBean.getPassword());
            if(isValidUser)
            {
                System.out.println("User login Successful");
                request.setAttribute("loggedInUser",loginBean.getUsername());
                mav = new ModelAndView("welcome");
            }
            else
            {
               mav=new ModelAndView("login");
               mav.addObject("loginBean", loginBean);
               request.setAttribute("message", "invalid Credentials");

            }

        }
        catch(Exception e)
        {
            e.printStackTrace();
        }


        return mav;
    }


}
