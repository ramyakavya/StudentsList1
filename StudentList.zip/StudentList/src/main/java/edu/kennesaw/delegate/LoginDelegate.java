package edu.kennesaw.delegate;

/**
 * Created by snellipudi on 8/2/2017.
 */
public class LoginDelegate {
    private UserService userService;

    public UserService getUserService()
    {
        return this.userService;
    }

    public void setUserService(UserService userService)
    {
        this.userService = userService;
    }

    public boolean isValidUser(String username, String password) throws SQLException
    {
        return userService.isValidUser(username, password);
    }
}
